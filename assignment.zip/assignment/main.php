<!-- carousel content begins -->
<section class="header_area">
    <div id="home" class="header_hero d-lg-flex align-items-center">
        <div class="hero_shape shape_1">
            <img src="assets/images/shape/shape-1.svg" alt="shape">
        </div><!-- hero shape -->
        <div class="hero_shape shape_2">
            <img src="assets/images/shape/shape-2.svg" alt="shape">
        </div><!-- hero shape -->
        <div class="hero_shape shape_3">
            <img src="assets/images/shape/shape-3.svg" alt="shape">
        </div><!-- hero shape -->
        <div class="hero_shape shape_4">
            <img src="assets/images/shape/shape-4.svg" alt="shape">
        </div><!-- hero shape -->
        <div class="hero_shape shape_6">
            <img src="assets/images/shape/shape-1.svg" alt="shape">
        </div><!-- hero shape -->
        <div class="hero_shape shape_7">
            <img src="assets/images/shape/shape-4.svg" alt="shape">
        </div><!-- hero shape -->
        <div class="hero_shape shape_8">
            <img src="assets/images/shape/shape-3.svg" alt="shape">
        </div><!-- hero shape -->
        <div class="hero_shape shape_9">
            <img src="assets/images/shape/shape-2.svg" alt="shape">
        </div><!-- hero shape -->
        <div class="hero_shape shape_10">
            <img src="assets/images/shape/shape-4.svg" alt="shape">
        </div><!-- hero shape -->
        <div class="hero_shape shape_11">
            <img src="assets/images/shape/shape-1.svg" alt="shape">
        </div><!-- hero shape -->
        <div class="hero_shape shape_12">
            <img src="assets/images/shape/shape-2.svg" alt="shape">
        </div><!-- hero shape -->

        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="header_hero_content">
                        <h2 class="hero_title wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.2s">Transform your businesses with Information <span>Technology</span></h2>
                        <ul>
                            <li class="wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.9s"><a class="main-btn" rel="nofollow" href="#">Learn More</a></li>
                        </ul>
                    </div> <!-- header hero content -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
        <div class="header_shape d-none d-lg-block"></div>

        <div class="header_image d-flex align-items-center">
            <div class="image">
                <img class="wow fadeInRightBig" data-wow-duration="2s" data-wow-delay="1.6s" src="assets/images/img5.jpg" alt="Header Image">
            </div>
        </div> <!-- header image -->
    </div> <!-- header hero -->
</section>
<!--====== carousel PART ENDS ======-->

<!--====== PRICING PLAN PART START ======-->
<section id="pricing" class="pricing_area pt-80">
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div id="webTable">
                <table>
                    <thead>
                        <tr>
                            <td>S/N</td>
                            <td>Full Name</td>
                            <td>Profession</td>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>John Doe</td>
                            <td>Software Engineer</td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>Lionel Messi</td>
                            <td>Footballer</td>
                        </tr>
                        <tr>
                            <td>3</td>
                            <td>Jeff Bezos</td>
                            <td>Entrepreneur</td>
                        </tr>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td>S/N</td>
                            <td>Full Name</td>
                            <td>Profession</td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div> <!-- row -->
</div> <!-- container -->
</section>
<!--====== PRICING PLAN PART ENDS ======-->