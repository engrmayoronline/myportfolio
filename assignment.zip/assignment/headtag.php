<meta charset="utf-8">
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!--====== Favicon Icon ======-->
<link rel="shortcut icon" href="assets/images/pseIcon.png" type="image/png">

<!--====== Animate CSS ======-->
<link rel="stylesheet" href="assets/css/animate.css">


<!--====== Line Icons CSS ======-->
<link rel="stylesheet" href="assets/fonts/lineicons/font-css/LineIcons.css">

<!--====== Bootstrap CSS ======-->
<link rel="stylesheet" href="assets/css/bootstrap.min.css">

<!--====== Default CSS ======-->
<link rel="stylesheet" href="assets/css/default.css">

<!--====== Style CSS ======-->
<link rel="stylesheet" href="assets/css/style.css">