<?php require("headercontent.php"); ?>
<!doctype html>
<html class="no-js" lang="en">
    <head>
        <!--====== Title ======-->
        <title><?= $titleContent["title"]["index"]; ?></title>
        <!-- start of the head tag content files -->
        <?php require ("headtag.php"); ?>
        <!-- end of the headtag content files -->
    </head>

    <body>
        <!--====== navigation PART START ======-->
        <?php include("navigation.php"); ?>
        <!-- end of navigation part -->

        <!-- main website homepage content begins here-->
        <?php include("main.php"); ?>
        <!-- main website homepage content ends here -->

        <!--====== FOOTER PART START ======-->
        <?php include("footer.php"); ?>
        <!--====== FOOTER PART ENDS ======-->
        
        <!--====== BACK TOP TOP PART START ======-->

        <a href="#" class="back-to-top"><i class="lni lni-chevron-up"></i></a>

        <!--====== BACK TOP TOP PART ENDS ======-->    

        <!--====== PART START ======-->

        <!--====== Jquery js ======-->
        <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
        <script src="assets/js/vendor/modernizr-3.7.1.min.js"></script>

        <!--====== Bootstrap js ======-->
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>

        <!--====== Scrolling Nav js ======-->
        <script src="assets/js/jquery.easing.min.js"></script>
        <script src="assets/js/scrolling-nav.js"></script>

        <!--====== Wow js ======-->
        <script src="assets/js/wow.min.js"></script>

        <!--====== Main js ======-->
        <script src="assets/js/main.js"></script>

        <!-- fontawesome -->
        
    </body>

</html>
