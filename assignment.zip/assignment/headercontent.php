<?php 
    $titleContent= array(
        "title"=> array(
            "index"=>"Consulting, Application Development, Systems Integration, and ISO Implementation Services Company",
            "aboutUs"=>"Consulting, Application Development, Systems Integration, and ISO Implementation Services Company"
        )
    );
?>