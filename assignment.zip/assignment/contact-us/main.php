<!-- carousel section -->
<section>
    <div id="home" class="header_hero d-lg-flex align-items-center">
        <div class="hero_shape shape_1">
            <img src="assets/images/shape/shape-1.svg" alt="shape">
        </div><!-- hero shape -->
        <div class="hero_shape shape_2">
            <img src="assets/images/shape/shape-2.svg" alt="shape">
        </div><!-- hero shape -->
        <div class="hero_shape shape_3">
            <img src="assets/images/shape/shape-3.svg" alt="shape">
        </div><!-- hero shape -->
        <div class="hero_shape shape_4">
            <img src="assets/images/shape/shape-4.svg" alt="shape">
        </div><!-- hero shape -->
        <div class="hero_shape shape_6">
            <img src="assets/images/shape/shape-1.svg" alt="shape">
        </div><!-- hero shape -->
        <div class="hero_shape shape_7">
            <img src="assets/images/shape/shape-4.svg" alt="shape">
        </div><!-- hero shape -->
        <div class="hero_shape shape_8">
            <img src="assets/images/shape/shape-3.svg" alt="shape">
        </div><!-- hero shape -->
        <div class="hero_shape shape_9">
            <img src="assets/images/shape/shape-2.svg" alt="shape">
        </div><!-- hero shape -->
        <div class="hero_shape shape_10">
            <img src="assets/images/shape/shape-4.svg" alt="shape">
        </div><!-- hero shape -->
        <div class="hero_shape shape_11">
            <img src="assets/images/shape/shape-1.svg" alt="shape">
        </div><!-- hero shape -->
        <div class="hero_shape shape_12">
            <img src="assets/images/shape/shape-2.svg" alt="shape">
        </div><!-- hero shape -->

        <!-- this is the container for the first title content -->
        <div class="container">
            <div class="row">
                <div class="col-md-3"></div>
                <div class="col-lg-6">
                    <div class="header_hero_content">
                        <h2 class="hero_title wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.2s">Contact <span>Us</span></h2>
                        <!-- <p class="wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.6s">All you need to know about <br> Panoramic Synergy Enterprises Ltd</p> -->
                    </div> <!-- header hero content -->
                    <center>
                        <div id="breadCrumbContainer">
                            <ul class="breadcrumb mb-4">
                                <li class="wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.9s">
                                    <a class="breadCrumb-btn breadcrumb-item" rel="nofollow" href="/">Home</a>
                                </li>
                                <li class="wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.9s">
                                    <a class="breadCrumb-btn breadcrumb-item active" rel="nofollow" href="javascript:void">/ Contact Us</a>
                                </li>
                            </ul>
                        </div>
                    </center>
                </div>
                <div class="col-md-3"></div>
            </div> <!-- row -->
        </div> <!-- container -->
        <div class="header_shape d-none d-lg-block"></div>
    </div> <!-- header hero -->
</section>
<!-- end of carousel section -->

<!--====== contact details PART START ======-->
<div id="contactDetails">
    <div class="container">
        How are you doing?
    </div> <!-- container -->
</div>
<!--====== contact details PART ENDS ======-->

